import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/shared/models/customer';
import { WishList } from 'src/app/shared/models/wishlist';
import { CustomerSharedService } from '../customer-shared-service';
import { WishlistService } from './wishlist.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  wishList: WishList[] = [];
  selectedWishListProduct: WishList;
  viewWishListProductDetails: boolean = false;
  successMessage: string;
  errorMessage: string;
  loggedInCustomer: any;
  constructor(private customerWishListService: WishlistService, private customerSharedService: CustomerSharedService) { }

  ngOnInit() {
    this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer"));
        this.customerWishListService.getCustomerWishList(this.loggedInCustomer.emailId).subscribe(
            wishList => {
                this.wishList = wishList;
                console.log(this.wishList)
                sessionStorage.setItem("wishList", JSON.stringify(this.wishList));
                this.customerSharedService.updateWishList(this.wishList)
            }, err => {
            }
        )
        this.viewWishListProductDetails = false;
  }

  setSelectedWishList(wishList: WishList) {
    this.successMessage = "";
    this.errorMessage = "";
    this.viewWishListProductDetails = true;
    this.selectedWishListProduct = wishList;

  }
  deleteProductFromWishList(wishList: WishList) {
    this.successMessage=null;
    this.errorMessage=null;
    let loggedInCustomer: Customer = JSON.parse(sessionStorage.getItem("customer"));
    this.customerWishListService.deleteProductFromWishList(wishList, loggedInCustomer.emailId).subscribe(
        message => {
            this.wishList = this.wishList.filter(item => item.wishListId !== wishList.wishListId);
            console.log(this.wishList)
            this.customerSharedService.updateWishList(this.wishList);
            sessionStorage.setItem("wishList", JSON.stringify(this.wishList));
            this.successMessage = message;
        }, error => this.errorMessage = <any>error
    )

}

}

