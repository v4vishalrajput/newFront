import { Product } from "./product";


export class WishList{
    wishListId:number;
	customerEmailId:string;
	product:Product;
	errorMessage:string; 
	successMessage:string;
}